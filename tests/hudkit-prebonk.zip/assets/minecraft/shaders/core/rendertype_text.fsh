#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

in vec2 localPos;
in vec2 quadSize;
in float pixelation;
in float cornerRadius;

out vec4 fragColor;

float roundedRectSDF(vec2 p, vec2 halfSize, float radius) {
    vec2 q = abs(p) - halfSize + radius;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
}

vec2 pixelate(vec2 p, float pixelSize) {
    if (pixelSize <= 1.0) return p; // No pixelation
    return floor(p / pixelSize) * pixelSize + pixelSize * 0.5;
}


void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }

    if (cornerRadius != 0.0) {
        vec2 centeredPos = (localPos - 0.5) * quadSize;
        vec2 pixelatedPos = pixelate(centeredPos, pixelation);
        vec2 halfSize = quadSize * 0.5;
        float radius = min(min(halfSize.x, halfSize.y), cornerRadius);
        float pixelatedRadius = pixelation > 1.0 ? floor(radius / pixelation) * pixelation: radius;
        float dist = roundedRectSDF(pixelatedPos, halfSize, pixelatedRadius);

        if (dist > 0.0) {
            discard;
        }
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}