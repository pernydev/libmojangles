#version 330

// Generated code, DO NOT EDIT
// https://hudkit.net

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Background element data pass to fragment
out vec2 localPos;
out vec2 quadSize;
out float pixelation;
out float cornerRadius;

vec2[] corners = vec2[](
vec2(0.0, 1.0),
vec2(0.0, 0.0),
vec2(1.0, 0.0),
vec2(1.0, 1.0)
);

bool close(float a, float b) {
return abs(a - b) < 0.05;
}

void main() {
    vec3 pos = Position;


    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    texCoord0 = UV0;

    localPos = vec2(0.0,0.0);
    quadSize = vec2(0.0,0.0);
    pixelation = 0.0;
    cornerRadius = 0.0;

    if (pos.y <= 1000) {
        gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    }
    // --------START CODEGEN--------
    else if (pos.y < 2149) {
        // hud_generic_center_0_0
        
        pos.y -= 2000 - -7;
        gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
        gl_Position.xy += vec2(0, -1);
    }else if (pos.y < 2649) {
        // hud_generic_bottom_center_-35_0
        
        pos.y -= 2500 - -45;
        gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
        gl_Position.xy += vec2(0, -2);
    }else if (pos.y < 3149) {
        // hud_text_bottom_center_-35_0
        
        pos.y -= 3000 - -45;
        gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
        gl_Position.xy += vec2(0, -2);
    }
    // ---------END CODEGEN--------
}
